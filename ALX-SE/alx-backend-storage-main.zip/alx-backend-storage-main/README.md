# ALX Backend Storage

Repository for projects pertaining to data storage.


## Author :black_nib:

* __Amos Mwongela Gabriel__ <[4ouR04](https://github.com/4ouR04)>

## Acknowledgements :pray:

Click this image for more information

<a href= "https://www.alxafrica.com/"><img style="width: 100%" src="img/alx.png" alt="Alx logo"></a>
