## 0x16. C - Simple Shell

A simple UNIX command interpreter written as part of the low-level programming and algorithm track at Alx 12-month course.


## Authors :black_nib:

* Oyebanji Olawale<[OyebanjiOlawale](https://github.com/OyebanjiOlawale)>
* Amos Mwongela<[cm-amos](https://github.com/cm-amos)>


