/**
 * add - addition
 * @a: number
 * @b: nuber
 * Return: result
 */
int add(int a, int b)
{
      return (a + b);
}
/**
 * sub - addition
 * @a: number
 * @b: nuber
 * Return: result
 */
int sub(int a, int b)
{
      return (a - b);
}
/**
 * mul - addition
 * @a: number
 * @b: nuber
 * Return: result
 */
int mul(int a, int b)
{
      return (a * b);
}
/**
 * div - addition
 * @a: number
 * @b: nuber
 * Return: result
 */
int div(int a, int b)
{
      return (a / b);
}
/**
 * mod - addition
 * @a: number
 * @b: nuber
 * Return: result
 */
int mod(int a, int b)
{
      return (a % b);
}
