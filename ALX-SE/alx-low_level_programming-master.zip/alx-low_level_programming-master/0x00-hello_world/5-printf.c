#include <stdio.h>

/**
* main - print the string in the put function
*
* Description: using the main function
* this program prints "Programming is like building a multilingual puzzle
* Return: 0
*/
int main(void)
{
	printf("with proper grammar, but the outcome is a piece of art,\n");
	return (0);
}
