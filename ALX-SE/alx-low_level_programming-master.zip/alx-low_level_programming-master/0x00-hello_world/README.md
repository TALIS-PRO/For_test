<a href="README.md"></a><h1>C - Hello, World</h1>
<ul>
  <li>0 - Write a script that runs a C file through the preprocessor and save the result into another file</li>
  <li>1 - Write a script that generates the assembly code of a C code and save it in an output file.</li>
  <li>2 - Write a script that compiles a C file but does not link.</li>
  <li>3 - Write a script that compiles a C file and creates an executable named cisfun.</li>
  <li>4 - Write a C program that prints exactly "Programming is like building a multilingual puzzle, followed by a new line.</li>
  <li>5 - Write a C program that prints exactly with proper grammar, but the outcome is a piece of art,, followed by a new line.</li>
  <li>6 - Write a C program that prints the size of various types on the computer it is compiled and run on.</li>
  <li>7 - (100 - Intel) Write a script that generates the assembly code (Intel syntax) of a C code and save it in an output file.</li>
  <li>8 - Write a C program that prints exactly and that piece of art is useful" - Dora Korpar, 2015-10-19, followed by a new line, to the standard error.<br>
         <i>You are not allowed to use any functions listed in the NAME section of the man (3) printf or man (3) puts</i><br>
         <i>Your program should return 1</i><br>
         <i>Your program should compile without any warnings when using the -Wall gcc option</i>
  </li>
</ul>
