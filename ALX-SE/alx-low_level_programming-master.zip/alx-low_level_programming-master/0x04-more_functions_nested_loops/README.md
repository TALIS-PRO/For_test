<h1>0x04. C - More functions, more nested loops</h1>
