<h1>0x07. C - Even more pointers, arrays and strings</h1>
