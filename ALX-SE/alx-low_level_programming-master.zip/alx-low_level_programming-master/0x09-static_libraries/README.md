This project is about C - Static libraries
