#!/usr/bin/env ruby
puts ARGV[0].scan(/hbt{2,5}n/).join
