# 0x10-https_ssl

Concepts learnt:
- What is HTTPS SSL 2 main roles
- What is the purpose encrypting traffic
- What SSL termination means