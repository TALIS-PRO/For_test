# 0x13-firewall

In this project, I learnt how to configure firewall to searvers.
