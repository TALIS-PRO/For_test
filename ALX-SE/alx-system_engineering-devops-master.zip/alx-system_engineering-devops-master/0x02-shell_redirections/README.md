This project covers basic concepts in Shell, I/O Redirections and filters
