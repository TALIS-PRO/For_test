This project covers concepts in Shell, init files, variables and expansions
