# 0x14. MySQL

In this project, I learned about:
- What is the main role of databases and db replica
- What is a database replica and how to create one


