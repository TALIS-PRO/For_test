# 0x0D-web_stack_debugging_0
<p>This is one among the <b>Webstack debugging series</b> of projects where I will be given <b>broken/bugged webstacks. The final goal is to come up with a Bash script that once executed, it will bring the webstack to a working state.</b></p>
